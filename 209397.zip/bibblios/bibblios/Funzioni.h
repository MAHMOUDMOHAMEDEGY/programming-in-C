
#ifndef FUNZIONI_H_INCLUDED
#define FUNZIONI_H_INCLUDED

//INCLUDES LIBRARIES

#include <stdbool.h>
#include <string.h>

#define CAPACITA_MIN 3
#define CAPACITA_MAX 1000
#define CAPACITA_STORIA 1000
#define IDENTITA 7

struct posto {
   char codice [IDENTITA];
   int genere; //1=uomo , 2=donna,
};

typedef struct node{
    struct posto item; /* elemento della lista */
    struct node *next; /* puntatore al successivo elemento della lista */
};

typedef struct sala{
    bool occupato;
    struct node *primo; /* puntatore al primo elemento della lista */
    struct node *ultimo; /* puntatore all'ultimo elemento della lista */
};

void inizializzaSala(struct  sala* array, int numero_posti);


void occupaPosto(struct sala * array, int posto);
void liberaPosto(struct sala * array, int posto);
void aggiungiPersona (struct sala * array, int posto, char *codice, int genere);
void visualizzasala(struct sala * array, int posti);
bool verificaStatoPosto(struct sala * array, int posto);
bool verificaCodicePersona(struct sala * array, char *codice, int posti);


int menuPrincipale();
void stampaStatistica();

bool esiste(char vet[][IDENTITA], int r, char elem[IDENTITA]);

#endif // FUNZIONI_H_INCLUDED
