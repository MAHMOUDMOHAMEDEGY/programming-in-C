#include "Funzioni.h"
#include <stdio.h>
FILE *f;



int main(void){

 //variabili sala
 int numero_posti;
 int posti_occupati=0;

 int uscite=0;
 int entrate=0;

 //variabili menu
 int scelta = -1;
 char invio;

 //variabili per statistiche per massimo numero di ingressi e uscite
 int nMax_entrate_consecutive = 0;
 int nMax_uscite_consecutive = 0;

 //variabili per la verifica dell'analisi Pattern 2
 bool conf_Pattern = false;
 int n_Uomo=0;
 int m_Donna=0;
 int n_postazione=0;

 //variabili per la verifica di patterns
 int n_ingressi_consecutivi = 0;
 int n_uscite_consecutive = 0;

 bool verifica_condizione_classica = false;
 bool verifica_condizione_specifica = false;

 int copia_n_ingressi_consecutivi = 0;

 int n_entrate_condizione_classica=3;
 int n_uscite_condizione_classica=3;
 int n_entrate_condizione_specifica=5;
 int n_uscite_condizione_specifica=2;
 int numeroPatterns=0;

  /*inserimento numero massimo posti disponibili*/
printf("\n**********************************************************************************************\n");
printf("\n\t\t\t\t Benvenuto!\n*\t Questo e' un gestionale per il controllo della sala della biblioteca universitaria.");
printf("*\n*\t Prima di iniziare, si prega di inserire il numero dei posti disponibili della sala: ");
printf("\n**********************************************************************************************\n");
scanf("%d", &numero_posti);
 while(numero_posti < CAPACITA_MIN || numero_posti > CAPACITA_MAX) {
       printf("\n\n\n\t\t La capacita del sala deve rispettare i seguenti vincoli!");
       printf("\n\t\t Capacita minima: %d", CAPACITA_MIN);
       printf("\n\t\t Capacita massima: %d", CAPACITA_MAX);
       printf("\n\n\n\t\t\t\t Posti disponibili: ");
       scanf("%d", &numero_posti);
 }

//struttura del sala basata su array bidimensionali
struct sala sala[numero_posti];
inizializzaSala(sala, numero_posti);

int i,j;

 while(scelta != 0) {
  scelta= menuPrincipale();
  switch(scelta){
          case 1:

                if (posti_occupati<numero_posti){

                 verifica_condizione_classica = false;
                 verifica_condizione_specifica = false;


                 //inserimento persona nel postazione

                 int genereCodice = 0, postazionePersona;
                 char codicePersona[IDENTITA];

                 printf("Si inserisca '1' per aggiungere un uomo in sala, '2' altrimenti:");
                 scanf("%d", &genereCodice);
                 scanf("%c", &invio);

                 while (genereCodice != 2 && genereCodice != 1 ) {
                printf("\n\t\t ERRORE. Si inserica il valore corretto '1' per aggiungere un uomo in sala, '2' altrimenti:");
                scanf("%d", &genereCodice);
                 scanf("%c", &invio);
    }
                 bool caratteri = false;
                 while(!caratteri){
                    printf("Si inserisca la matricola dello studente di %d caratteri alfanumerici:", IDENTITA-1);
                    char codiceMatricola[IDENTITA];
                    scanf("%s", codiceMatricola);
                    scanf("%c", &invio);
                    int len = strlen(codiceMatricola);
                    if (len == IDENTITA -1){
                        strcpy(codicePersona, codiceMatricola);
                        caratteri = true;
                    }
                    else
                        printf("La matricola non e' conforme di %d caratteri\n\n", IDENTITA-1);
                 }

                 //verifica se la matricola � gi� nel sala

                 if (verificaCodicePersona(sala, codicePersona, numero_posti)){
                    printf("Lo studente con matricola %s di genere %d e' gia' presente in sala \n", codicePersona, genereCodice);
                    printf("\n\nBatti un tasto");
                    scanf("%c", &invio);
                    break;
                 }

                 //inserisci persona nel primo postazione disponibile

                 bool postazione_trovato=false;
                 int p=0;
                 while (!postazione_trovato){
                   if (!verificaStatoPosto(sala, p)) {
                        aggiungiPersona(sala, p, codicePersona, genereCodice);
                        postazione_trovato=true;
                   }
                   else
                        p++;
                 }

                 printf("Lo studente con matricola %s di genere %d e' stato inserito nella postazione: %d\n", codicePersona, genereCodice, p);

                 posti_occupati++;
                 entrate++;

                 if (n_uscite_consecutive > nMax_uscite_consecutive){
                    nMax_uscite_consecutive = n_uscite_consecutive;
                 }

                 n_uscite_consecutive = 0;
                 n_ingressi_consecutivi ++;

                 printf("Persona entrata <---");
                 printf("\n\n\nBatti un tasto");
                 scanf("%c", &invio);
                }
                else {
                 printf("ERRORE. La capacita' della sala e' stata raggiunta. Si prega di riprovare piu' tardi\n");
                 printf("\n\n\nBatti un tasto");
                 scanf("%c", &invio);
                }
                break;

          case 2:
                if (posti_occupati>0){

                 int generePersona, postazionePersona;
                 char codicePersona [IDENTITA];

                 printf("Si prega di inserire la postazione che si vuole liberare:");
                 scanf("%d", & postazionePersona);
                 scanf("%c", &invio);

                 if(sala[postazionePersona].occupato){

                 sala[postazionePersona].occupato = false;

                 printf("\n\n\nLo studente di genere %d  con matricola %s nella postazione %d ha appena lasciato la sala, uscita --->\n", sala[postazionePersona].ultimo ->item.genere, sala[postazionePersona].ultimo ->item.codice, postazionePersona);

                 if (n_uscite_consecutive == 0)
                    copia_n_ingressi_consecutivi = n_ingressi_consecutivi;

                 posti_occupati--;
                 uscite++;

                 if (n_ingressi_consecutivi > nMax_entrate_consecutive){
                    nMax_entrate_consecutive = n_ingressi_consecutivi;
                 }


                 if (n_ingressi_consecutivi >= n_entrate_condizione_classica){
                    verifica_condizione_classica = true;
                 }
                 if (n_ingressi_consecutivi >= n_entrate_condizione_specifica){
                    verifica_condizione_specifica = true;
                 }


                 n_ingressi_consecutivi = 0;
                 n_uscite_consecutive ++;

                 if (n_uscite_consecutive == n_uscite_condizione_classica && verifica_condizione_classica){
                    printf("Condizione classica verificato: %d entrate totali consecutive %d entrate e %d uscite\n", copia_n_ingressi_consecutivi, n_entrate_condizione_classica, n_uscite_condizione_classica );
                    numeroPatterns++;
                 }
                 if (n_uscite_consecutive == n_uscite_condizione_specifica && verifica_condizione_specifica){
                    printf("Condizione specifica verificato: %d entrate totali consecutive %d entrate e %d uscite\n", copia_n_ingressi_consecutivi, n_entrate_condizione_specifica, n_uscite_condizione_specifica );
                    numeroPatterns++;
                 }

                    numeroPatterns++;
                 }
                 else
                    printf("La postazione %d risulta libera", postazionePersona);

                 printf("\n\n\nBatti un tasto");
                 scanf("%c", &invio);
                }
                else {
                 printf("La sala e' vuota.\n");
                 printf("\n\n\nBatti un tasto");
                 scanf("%c", &invio);
                }
                break;

          case 3:
                stampaStatistica();
                printf("\t\t\t Numero di persone %d \n\t\t\t Posti liberi %d/%d totali\n", posti_occupati, numero_posti-posti_occupati, numero_posti);
                float percent = ((float)(numero_posti-posti_occupati)/numero_posti)*100;
                printf("\t\t\t Percentuale posti liberi: %.2f \n", percent);
                printf("\t\t\t Numero di ingressi registrati ad oggi: %d \n", entrate);
                printf("\t\t\t Numero di uscite registrate ad oggi: %d \n", uscite);
                if (n_ingressi_consecutivi > nMax_entrate_consecutive){
                    nMax_entrate_consecutive = n_ingressi_consecutivi;
                 }
                if (n_uscite_consecutive > nMax_uscite_consecutive){
                    nMax_uscite_consecutive = n_uscite_consecutive;
                 }
                printf("\t\t\t Numero massimo di ingressi consecutivi: %d \n", nMax_entrate_consecutive);
                printf("\t\t\t Numero massimo di uscite consecutive: %d \n", nMax_uscite_consecutive);

                printf("\t\t\t Numero di Pattern riconosciuti: %d \n", numeroPatterns);

                //visualizza contenuto del sala
                int numero_uomo=0;
                int numeo_donne=0;
                printf("\n\t\t\t Posti: \n");
                int p;
                struct node *temp;
                for (p=0; (p<numero_posti); p++) {
                    temp = sala[p].ultimo;
                    if (temp != NULL & sala[p].occupato){
                        printf("\t\t\t Posti[%d] = %d, %s\n", p, temp -> item.genere, temp -> item.codice);
                        if (temp -> item.genere==1) numero_uomo++;
                        else
                        if (temp -> item.genere==2) numeo_donne++;

                    }else
                        printf("\t\t\t Posti[%d] = LIBERO,\n", p);
                }

                printf("\t\t\t Numero uomo=%d, Numero donne=%d ",numero_uomo,numeo_donne);

                printf("\n\t\t\t Lista di posti in cui ci sono uomini:\n");

                for (p=0; (p<numero_posti); p++)
                    if (sala[p].ultimo != NULL)
                        if (sala[p].occupato & sala[p].ultimo -> item.genere==1) printf("\t\t\t %d, ",p);

                printf("\n\n");
                printf("\t\t\t Lista di posti in cui ci sono donne:\n");

                for (p=0; (p<numero_posti); p++)
                    if (sala[p].ultimo != NULL)
                        if (sala[p].occupato & sala[p].ultimo -> item.genere==2) printf("\t\t\t %d, ",p);

                printf("\n\n");

                //stampa storia ed aggregati e calcola massimi assoluti

                int nMax_uomini=0, nMax_donne=0;
                for (p=0; (p<numero_posti); p++){
                    printf("\n\t\t\tpostazione %d: ",p);
                    int p1;
                    int a=0, m=0;
                    temp = sala[p].primo;
                    while(temp != NULL){
                        printf("%d-", temp -> item.genere);
                        if (temp -> item.genere==1)
                            a=a+1;
                        else
                            if (temp -> item.genere==2)
                                m=m+1;
                        temp = temp -> next;
                    }
                    if (a>nMax_uomini) nMax_uomini=a;
                    if (m>nMax_donne) nMax_donne=m;
                    printf("-> n uomini=%d, n donna=%d",a,m);
                }
                //qua stampa i massimi
                printf("\n\t\t\t Massimi: nMax_uomini=%d, nMax_donne=%d \n",nMax_uomini,nMax_donne);

		  //Lista dei codici di tutte le persone che hanno visitato il sala

            {
              char lista_codici[entrate+1][IDENTITA];
              int codice_n_volte[entrate+1];
              int r=0;
              for (p=0; (p<numero_posti); p++){
                temp = sala[p].primo;
                while(temp != NULL){
                if ((strcmp(temp -> item.codice,"")!=NULL) && (!esiste(lista_codici, r, temp -> item.codice))) {
                 strcpy(lista_codici[r], temp -> item.codice);
                 printf("\t\t\t matricola dello studente: %s\n",lista_codici[r]);
                 r++;
                }
                temp = temp -> next;
                }
              }

                int c;
                int comp;
                for (i=0;i<r;i++){
                    c=0;
                    for (p=0; (p<numero_posti); p++){
                        temp = sala[p].primo;
                        while(temp != NULL){
                          if (((strcmp(temp -> item.codice,"")!=NULL) && strcmp(temp -> item.codice, lista_codici[i]) == 0)){
                            c=c+1;
                            codice_n_volte[i]=c;
                        }
                        temp = temp -> next;
                        }
                    }
                printf("\t\t\t Lo studente con matricola %s e' presente %d volte\n", lista_codici[i], codice_n_volte[i]);

                }

                // ordinamento selection sort

                int i, j, min, temp;
                char temp_codice[IDENTITA];
                for(i=0; i<r-1; i++) {
                    min = i;

                    for(j=i+1; j<r; j++){
                       if(codice_n_volte[j] < codice_n_volte[min]) //cambiare questa condizione per invertire l'ordine
                            min = j;

                        temp=codice_n_volte[min];
                        codice_n_volte[min]=codice_n_volte[i];
                        codice_n_volte[i]=temp;
                        strcpy(temp_codice, lista_codici[min]);
                        strcpy(lista_codici[min], lista_codici[i]);
                        strcpy(lista_codici[i], temp_codice);
                    }
                }
                printf("\n\n\t\t\t Lista dei codici ordinate tramite Selection Sort\n\n");

                    for(i=0; i<r; i++) {
                        printf("\t\t\t Lo studente con matricola %s e' presente %d volte\n", lista_codici[i], codice_n_volte[i]);
                    }

                }
                printf("\n");
                printf("\n\n\nBatti un tasto");
                scanf("%c", &invio);
                break;

          case 4:
              f=fopen("storicoBiblioteca.txt", "w+");
                if (f != NULL) {
                    fprintf(f, "%d ", posti_occupati); //posti occupati
                    fprintf(f, "%d ", entrate); //entrate
                    fprintf(f, "%d\n", numero_posti); //numero posti
                    struct node *temp;
                    for(i=0; i<numero_posti; i++){
                        temp = sala[i].primo;
                        while(temp != NULL){
                            fprintf (f, "%d " , i); //postazione
                            fprintf (f, "%d " , temp->item.genere); //genere
                            fprintf (f, "%s " , temp->item.codice); //codice
                            if(sala[i].occupato == true) //stato
                                fprintf (f, "%d\n" , 1);
                            else
                                fprintf (f, "%d\n" , 0);
                            temp = temp -> next;
                        }
                    }
                }
                fclose(f);

                printf("\n\n\t\t\t\t sala salvato\n\n\n");
                printf("\n\n\nBatti un tasto");
                scanf("%c", &invio);
                break;

          case 5:
                f= fopen("storicoBiblioteca.txt", "r");
                if (f != NULL){
                    fscanf(f,"%d %d %d",&posti_occupati, &entrate, &numero_posti);
                    printf("%d - %d - %d\n",posti_occupati, entrate, numero_posti);
                    inizializzaSala(sala, numero_posti);
                    int tmp_postazione;
                    char tmp_codice [IDENTITA];
                    int tmp_genere;
                    int tmp_stato;
                    while(fscanf(f,"%d %d %s %d",&tmp_postazione, &tmp_genere, tmp_codice, &tmp_stato) != EOF) {
                        printf("%d - %d - %s - %d\n",tmp_postazione, tmp_genere, tmp_codice, tmp_stato);
                        aggiungiPersona(sala, tmp_postazione, tmp_codice, tmp_genere);
                        if(tmp_stato == 1)
                            occupaPosto(sala, tmp_postazione);
                        else
                            liberaPosto(sala, tmp_postazione);
                    }
                }
                fclose(f);

                printf("\n\n\t\t\t\t sala caricata Correttamente\n\n\n");
                printf("\n\n\nBatti un tasto");
                scanf("%c", &invio);
                break;

          case 0: printf("sala chiuso!!!\n");

  } //switch
 } //while
} //main




