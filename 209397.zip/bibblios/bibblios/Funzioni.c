
#include "Funzioni.h"
#include <stdio.h>
#include <stdlib.h>


void inizializzaSala(struct  sala* array, int numero_posti){
    int i;
    for (i=0; i<numero_posti; i++){
        array[i].occupato = false;
        array[i].primo = NULL;
        array[i].ultimo = NULL;
    }
}

void occupaPosto(struct sala * array, int posto){
    array[posto].occupato = true;
}

void liberaPosto(struct sala * array, int posto){
    array[posto].occupato = false;
}

void aggiungiPersona (struct sala * array, int posto, char *codice, int genere){

    struct node *newnode;
    newnode = (struct node *) malloc(sizeof(struct node));
    newnode ->next = NULL;
    strcpy(newnode->item.codice, codice);
    newnode ->item.genere = genere;

    if (array[posto].primo == NULL){
        array[posto].primo = newnode;
        array[posto].ultimo = newnode;
    }

    else{
        array[posto].ultimo -> next = newnode;
        array[posto].ultimo = newnode;
    }
    occupaPosto(array, posto);
}
bool verificaStatoPosto(struct sala * array, int posto){
    if(array[posto].occupato == false)
        return false;
    else
        return true;
}

void visualizzasala(struct sala * array, int posti){
    int i;
    struct node *temp;
    for(i=0; i<posti; i++){
        temp = array[i].primo;
        while(temp != NULL){
            printf("Nel posto %d e presente una persona con codice: %s, di genere %d\n", i, temp -> item.codice, temp -> item.genere);
            temp = temp -> next;
        }
    }
}



bool verificaCodicePersona(struct sala * array, char *codice, int posti){
    int i;
    for (i=0; i<posti; i++){
        if(array[i].occupato == true && strcmp(codice, array[i].ultimo -> item.codice) == 0)
            return true;
    }
     return false;
}





int menuPrincipale(){
  int scelta=-1;
  char invio;
  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
  printf("\t\t\t************************\n");
  printf("\t\t\t*     BIBLIOTECA       *\n\t\t\t*    -GESTIONALE-      *\n");
   printf("\t\t\t************************\n");
  printf("\n\n\n\t\t\t 1. Entrata Persona");
  printf("\n\n\t\t\t 2. Uscita Persona");
  printf("\n\n\t\t\t 3. Statistiche");
  printf("\n\n\t\t\t 4. Salva");
  printf("\n\n\t\t\t 5. Carica file");
  printf("\n\n\t\t\t 0. fine");
  printf("\n\n\n\t\t\t\t Scegliere una opzione: ");
  scanf("%d", &scelta);
  scanf("%c", &invio);
  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
  return scelta;
}


bool esiste(char vet[][IDENTITA], int r, char elem[IDENTITA]){
 bool trovato=false;
 int i=0;
 while (!trovato && i<r){
  if (strcmp(elem,vet[i])==0) trovato=true;
  i=i+1;
 }
 return trovato;
}

void stampaStatistica(){
  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
  printf("\t\t\t************************\n");
  printf("\t\t\t*     STATISTICHE      *\n");
  printf("\t\t\t************************\n");
  printf("\t\t_________________________________________________________________________\n\n");
  printf("\t\t\t>\t Situazione postazioni libere/occupate:\n");
}


